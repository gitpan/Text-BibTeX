#include <ctype.h>
#include "prototypes.h"

/* ------------------------------------------------------------------------
@NAME       : strlwr()
@INPUT      : 
@OUTPUT     : 
@RETURNS    : 
@DESCRIPTION: Converts a string to lowercase in place.
@GLOBALS    : 
@CALLS      : 
@CREATED    : 1996/01/06, GPW
@MODIFIED   : 
@COMMENTS   : This should work the same as strlwr() in DOS compilers --
              why this isn't mandated by ANSI is a mystery to me...
-------------------------------------------------------------------------- */
#if !HAVE_STRLWR
char *strlwr (char *s)
{
   int  len, i;

   len = strlen (s);
   for (i = 0; i < len; i++)
      s[i] = tolower (s[i]);

   return s;
}
#endif



/* ------------------------------------------------------------------------
@NAME       : strupr()
@INPUT      : 
@OUTPUT     : 
@RETURNS    : 
@DESCRIPTION: Converts a string to uppercase in place.
@GLOBALS    : 
@CALLS      : 
@CREATED    : 1996/01/06, GPW
@MODIFIED   : 
@COMMENTS   : This should work the same as strlwr() in DOS compilers --
              why this isn't mandated by ANSI is a mystery to me...
-------------------------------------------------------------------------- */
#if !HAVE_STRUPR
char *strupr (char *s)
{
   int  len, i;

   len = strlen (s);
   for (i = 0; i < len; i++)
      s[i] = toupper (s[i]);

   return s;
}
#endif

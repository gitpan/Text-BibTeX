#ifndef tokens_h
#define tokens_h
/* tokens.h -- List of labelled tokens and stuff
 *
 * Generated from: bibtex.g
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * ANTLR Version 1.33
 */
#define zzEOF_TOKEN 1
#define AT 3
#define ENTRY_TYPE 7
#define ENTRY_OPEN 8
#define ENTRY_KEY 11
#define KEYWORD 14
#define EQUALS 15
#define HASH 16
#define COMMA 17
#define NUMBER 18
#define ENTRY_CLOSE 20
#define STRING 26

#ifdef __STDC__
void bibfile(AST**_root);
#else
extern void bibfile();
#endif

#ifdef __STDC__
void entry(AST**_root, int cur_line );
#else
extern void entry();
#endif

#ifdef __STDC__
void contents(AST**_root);
#else
extern void contents();
#endif

#ifdef __STDC__
void fields(AST**_root);
#else
extern void fields();
#endif

#ifdef __STDC__
void field(AST**_root);
#else
extern void field();
#endif

#ifdef __STDC__
void field_data(AST**_root);
#else
extern void field_data();
#endif

#ifdef __STDC__
void field_datum(AST**_root);
#else
extern void field_datum();
#endif

#endif
extern SetWordType zzerr1[];
extern SetWordType zzerr2[];
extern SetWordType zzerr3[];
extern SetWordType setwd1[];

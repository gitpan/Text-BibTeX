#ifndef UTIL_H
#define UTIL_H

char *strlwr (char *s);
char *strupr (char *s);

#endif /* UTIL_H */

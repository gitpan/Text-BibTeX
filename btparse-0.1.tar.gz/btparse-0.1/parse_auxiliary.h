/* ------------------------------------------------------------------------
@NAME       : parse_auxiliary.h
@INPUT      : 
@OUTPUT     : 
@RETURNS    : 
@DESCRIPTION: Prototype declarations for functions in parse_auxiliary.c
@GLOBALS    : 
@CALLS      : 
@CREATED    : 1997/01/08, Greg Ward
@MODIFIED   : 
@VERSION    : $Id: parse_auxiliary.h,v 1.1 1997/01/09 03:06:55 greg Exp $
-------------------------------------------------------------------------- */

#ifndef PARSE_AUXILIARY_H
#define PARSE_AUXILIARY_H

void fix_token_names (void);
void zzsyn (char *text, int tok, 
            char *egroup, SetWordType *eset, int etok,
            int k, char *bad_text);

#endif /* PARSE_AUXILIARY_H */

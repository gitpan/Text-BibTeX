
/* parser.dlg -- DLG Description of scanner
 *
 * Generated from: bibtex.g
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-1994
 * Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33
 */

#include <stdio.h>
#define ANTLR_VERSION	133

#define ZZCOL
#define USER_ZZSYN

#include "attrib.h"
#include "lex_auxiliary.h"
#include "error.h"
#include "bibtex_ast.h"
#include "antlr.h"
#include "ast.h"
#include "tokens.h"
#include "dlgdef.h"
LOOKAHEAD
void zzerraction()
{
	(*zzerr)("invalid token");
	zzadvance();
	zzskip();
}
/*
 * D L G tables
 *
 * Generated from: parser.dlg
 *
 * 1989-1994 by  Will Cohen, Terence Parr, and Hank Dietz
 * Purdue University Electrical Engineering
 * DLG Version 1.33
 */

#include "mode.h"



static void act1()
{ 
		NLA = 1;
	}


static void act2()
{ 
		NLA = 2;
		newline ();   
	}


static void act3()
{ 
		NLA = AT;
		zzmode (LEX_ENTRY);   
	}


static void act4()
{ 
		NLA = 4;
		zzskip ();   
	}

static unsigned char shift0[257] = {
  0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 1, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 2, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3
};


static void act5()
{ 
		NLA = 1;
	}


static void act6()
{ 
		NLA = 5;
		newline ();   
	}


static void act7()
{ 
		NLA = 6;
		zzskip ();   
	}


static void act8()
{ 
		NLA = ENTRY_TYPE;
		set_entry_type (zzlextext);   
	}


static void act9()
{ 
		NLA = ENTRY_OPEN;
		open_entry (*zzlextext);   
	}

static unsigned char shift1[257] = {
  0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  2, 1, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 2, 3, 6, 6, 3, 6, 3, 
  6, 5, 6, 3, 3, 6, 3, 3, 3, 4, 
  4, 4, 4, 4, 4, 4, 4, 4, 4, 3, 
  3, 3, 6, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 5, 3, 6, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3
};


static void act10()
{ 
		NLA = 1;
	}


static void act11()
{ 
		NLA = 9;
		newline ();   
	}


static void act12()
{ 
		NLA = 10;
		zzskip ();   
	}


static void act13()
{ 
		NLA = ENTRY_KEY;
		zzmode (LEX_FIELD);   
	}

static unsigned char shift2[257] = {
  0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  2, 1, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 2, 3, 5, 5, 3, 5, 3, 
  5, 5, 5, 3, 3, 5, 3, 3, 3, 4, 
  4, 4, 4, 4, 4, 4, 4, 4, 4, 3, 
  3, 3, 5, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 5, 3, 5, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3
};


static void act14()
{ 
		NLA = 1;
	}


static void act15()
{ 
		NLA = 12;
		newline ();   
	}


static void act16()
{ 
		NLA = 13;
		zzskip ();   
	}


static void act17()
{ 
		NLA = KEYWORD;
	}


static void act18()
{ 
		NLA = EQUALS;
	}


static void act19()
{ 
		NLA = HASH;
	}


static void act20()
{ 
		NLA = COMMA;
	}


static void act21()
{ 
		NLA = NUMBER;
	}


static void act22()
{ 
		NLA = 19;
		start_string (*zzlextext);   
	}


static void act23()
{ 
		NLA = ENTRY_CLOSE;
		close_entry (*zzlextext);   
	}

static unsigned char shift3[257] = {
  0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  2, 1, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 2, 3, 8, 6, 3, 10, 3, 
  10, 10, 9, 3, 3, 7, 3, 3, 3, 4, 
  4, 4, 4, 4, 4, 4, 4, 4, 4, 3, 
  3, 3, 5, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 8, 3, 9, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 
  3, 3, 3, 3, 3, 3, 3
};


static void act24()
{ 
		NLA = 1;
	}


static void act25()
{ 
		NLA = 21;
		newline_in_string ();   
	}


static void act26()
{ 
		NLA = 22;
		zzreplchar (' '); zzmore ();   
	}


static void act27()
{ 
		NLA = 23;
		open_brace ();   
	}


static void act28()
{ 
		NLA = 24;
		close_brace ();   
	}


static void act29()
{ 
		NLA = 25;
		zzmore ();   
	}


static void act30()
{ 
		NLA = STRING;
		quote_in_string ();   
	}


static void act31()
{ 
		NLA = 27;
		zzmore ();   
	}

static unsigned char shift4[257] = {
  0, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  2, 1, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 6, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 5, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 3, 7, 4, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 
  7, 7, 7, 7, 7, 7, 7
};

#define DfaStates	40
typedef unsigned char DfaState;

static DfaState st0[5] = {
  1, 2, 3, 4, 40
};

static DfaState st1[5] = {
  40, 40, 40, 40, 40
};

static DfaState st2[5] = {
  40, 40, 40, 40, 40
};

static DfaState st3[5] = {
  40, 40, 40, 40, 40
};

static DfaState st4[5] = {
  40, 40, 40, 4, 40
};

static DfaState st5[7] = {
  6, 7, 8, 9, 40, 10, 40
};

static DfaState st6[7] = {
  40, 40, 40, 40, 40, 40, 40
};

static DfaState st7[7] = {
  40, 40, 40, 40, 40, 40, 40
};

static DfaState st8[7] = {
  40, 40, 8, 40, 40, 40, 40
};

static DfaState st9[7] = {
  40, 40, 40, 11, 11, 40, 40
};

static DfaState st10[7] = {
  40, 40, 40, 40, 40, 40, 40
};

static DfaState st11[7] = {
  40, 40, 40, 11, 11, 40, 40
};

static DfaState st12[6] = {
  13, 14, 15, 16, 40, 40
};

static DfaState st13[6] = {
  40, 40, 40, 40, 40, 40
};

static DfaState st14[6] = {
  40, 40, 40, 40, 40, 40
};

static DfaState st15[6] = {
  40, 40, 15, 40, 40, 40
};

static DfaState st16[6] = {
  40, 40, 40, 17, 17, 40
};

static DfaState st17[6] = {
  40, 40, 40, 17, 17, 40
};

static DfaState st18[11] = {
  19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 
  40
};

static DfaState st19[11] = {
  40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 
  40
};

static DfaState st20[11] = {
  40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 
  40
};

static DfaState st21[11] = {
  40, 40, 21, 40, 40, 40, 40, 40, 40, 40, 
  40
};

static DfaState st22[11] = {
  40, 40, 40, 29, 29, 40, 40, 40, 40, 40, 
  40
};

static DfaState st23[11] = {
  40, 40, 40, 40, 23, 40, 40, 40, 40, 40, 
  40
};

static DfaState st24[11] = {
  40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 
  40
};

static DfaState st25[11] = {
  40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 
  40
};

static DfaState st26[11] = {
  40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 
  40
};

static DfaState st27[11] = {
  40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 
  40
};

static DfaState st28[11] = {
  40, 40, 40, 40, 40, 40, 40, 40, 40, 40, 
  40
};

static DfaState st29[11] = {
  40, 40, 40, 29, 29, 40, 40, 40, 40, 40, 
  40
};

static DfaState st30[9] = {
  31, 32, 33, 34, 35, 36, 37, 38, 40
};

static DfaState st31[9] = {
  40, 40, 40, 40, 40, 40, 40, 40, 40
};

static DfaState st32[9] = {
  40, 40, 40, 40, 40, 40, 40, 40, 40
};

static DfaState st33[9] = {
  40, 40, 40, 40, 40, 40, 40, 40, 40
};

static DfaState st34[9] = {
  40, 40, 40, 40, 40, 40, 40, 40, 40
};

static DfaState st35[9] = {
  40, 40, 40, 40, 40, 40, 40, 40, 40
};

static DfaState st36[9] = {
  40, 39, 39, 39, 39, 39, 39, 39, 40
};

static DfaState st37[9] = {
  40, 40, 40, 40, 40, 40, 40, 40, 40
};

static DfaState st38[9] = {
  40, 40, 40, 40, 40, 40, 40, 38, 40
};

static DfaState st39[9] = {
  40, 40, 40, 40, 40, 40, 40, 40, 40
};


DfaState *dfa[40] = {
	st0,
	st1,
	st2,
	st3,
	st4,
	st5,
	st6,
	st7,
	st8,
	st9,
	st10,
	st11,
	st12,
	st13,
	st14,
	st15,
	st16,
	st17,
	st18,
	st19,
	st20,
	st21,
	st22,
	st23,
	st24,
	st25,
	st26,
	st27,
	st28,
	st29,
	st30,
	st31,
	st32,
	st33,
	st34,
	st35,
	st36,
	st37,
	st38,
	st39
};


DfaState accepts[41] = {
  0, 1, 2, 3, 4, 0, 5, 6, 7, 8, 
  9, 8, 0, 10, 11, 12, 13, 13, 0, 14, 
  15, 16, 17, 21, 18, 19, 20, 22, 23, 17, 
  0, 24, 25, 26, 27, 28, 0, 30, 31, 29, 0
};

void (*actions[32])() = {
	zzerraction,
	act1,
	act2,
	act3,
	act4,
	act5,
	act6,
	act7,
	act8,
	act9,
	act10,
	act11,
	act12,
	act13,
	act14,
	act15,
	act16,
	act17,
	act18,
	act19,
	act20,
	act21,
	act22,
	act23,
	act24,
	act25,
	act26,
	act27,
	act28,
	act29,
	act30,
	act31
};

static DfaState dfa_base[] = {
	0,
	5,
	12,
	18,
	30
};

static unsigned char *b_class_no[] = {
	shift0,
	shift1,
	shift2,
	shift3,
	shift4
};

#define ZZINTERACTIVE

static unsigned char zzalternatives[DfaStates+1] = {
	1,
	0,
	0,
	0,
	1,
	1,
	0,
	0,
	1,
	1,
	0,
	1,
	1,
	0,
	0,
	1,
	1,
	1,
	1,
	0,
	0,
	1,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	0,
	0,
	0,
	0,
	0,
	1,
	0,
	1,
	0,
/* must have 0 for zzalternatives[DfaStates] */
	0
};



#define ZZSHIFT(c) (b_class_no[zzauto][1+c])
#define MAX_MODE 5
#include "dlgauto.h"

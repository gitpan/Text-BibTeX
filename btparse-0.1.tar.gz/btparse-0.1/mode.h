#define START 0
#define LEX_ENTRY 1
#define LEX_KEY 2
#define LEX_FIELD 3
#define LEX_STRING 4

#ifndef ATTRIB_H
#define ATTRIB_H

/*
 * Defining Attrib this way (as opposed to making it a pointer to a struct)
 * avoid the expense of allocating/deallocating a structure for each token;
 * this way, PCCTS statically allocates the whole stack once and that's
 * it.  (Of course, the stack is four times bigger than it would have been
 * otherwise.)
 */

typedef struct {
   int    line;
   int    offset;
   int    token;
   char  *text;
} Attrib;

#endif /* ATTRIB_H */

/*
 * A n t l r  S e t s / E r r o r  F i l e  H e a d e r
 *
 * Generated from: bibtex.g
 *
 * Terence Parr, Russell Quong, Will Cohen, and Hank Dietz: 1989-1995
 * Parr Research Corporation
 * with Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33
 */

#include <stdio.h>
#define ANTLR_VERSION	133

#define ZZCOL
#define USER_ZZSYN

#include "attrib.h"
#include "lex_auxiliary.h"
#include "error.h"
#include "bibtex_ast.h"
#define zzSET_SIZE 4
#include "antlr.h"
#include "ast.h"
#include "tokens.h"
#include "dlgdef.h"
#include "err.h"

ANTLRChar *zztokens[28]={
	/* 00 */	"Invalid",
	/* 01 */	"@",
	/* 02 */	"\\n",
	/* 03 */	"AT",
	/* 04 */	"~[\\n\\@]+",
	/* 05 */	"\\n",
	/* 06 */	"[\\ \\t]+",
	/* 07 */	"ENTRY_TYPE",
	/* 08 */	"ENTRY_OPEN",
	/* 09 */	"\\n",
	/* 10 */	"[\\ \\t]+",
	/* 11 */	"ENTRY_KEY",
	/* 12 */	"\\n",
	/* 13 */	"[\\ \\t]+",
	/* 14 */	"KEYWORD",
	/* 15 */	"EQUALS",
	/* 16 */	"HASH",
	/* 17 */	"COMMA",
	/* 18 */	"NUMBER",
	/* 19 */	"[\\{\"]",
	/* 20 */	"ENTRY_CLOSE",
	/* 21 */	"\\n",
	/* 22 */	"\\t",
	/* 23 */	"\\{",
	/* 24 */	"\\}",
	/* 25 */	"\\~[]",
	/* 26 */	"STRING",
	/* 27 */	"~[\\n\\t\\{\\}\"\\]+"
};
SetWordType zzerr1[4] = {0x0,0x48,0x0,0x0};
SetWordType zzerr2[4] = {0x0,0x40,0x10,0x0};
SetWordType zzerr3[4] = {0x0,0x40,0x4,0x4};
SetWordType setwd1[28] = {0x0,0x3,0x0,0x2,0x0,0x0,0x0,
	0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
	0x0,0x40,0x70,0x0,0x0,0x7c,0x0,0x0,
	0x0,0x0,0x0,0x0,0x0};

/* ------------------------------------------------------------------------
@NAME       : init.c
@DESCRIPTION: Initialization and cleanup functions for the btparse library.
@GLOBALS    : 
@CALLS      : 
@CREATED    : 1997/01/19, Greg Ward
@MODIFIED   : 
@VERSION    : $Id: init.c,v 1.1 1997/02/04 01:21:48 greg Exp $
-------------------------------------------------------------------------- */

#include "prototypes.h"

void bt_initialize (void)
{
   /* Initialize data structures */

   fix_token_names ();
   init_macros ();
}


void bt_cleanup (void)
{
   done_macros ();
}
